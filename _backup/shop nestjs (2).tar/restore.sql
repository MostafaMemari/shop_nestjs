--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-2.pgdg120+1)
-- Dumped by pg_dump version 15.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "shop-mng";
--
-- Name: shop-mng; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE "shop-mng" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "shop-mng" OWNER TO root;

\connect -reuse-previous=on "dbname='shop-mng'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: invoice_item_status_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.invoice_item_status_enum AS ENUM (
    'success',
    'failed'
);


ALTER TYPE public.invoice_item_status_enum OWNER TO root;

--
-- Name: invoice_status_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.invoice_status_enum AS ENUM (
    'success',
    'partial_success'
);


ALTER TYPE public.invoice_status_enum OWNER TO root;

--
-- Name: invoice_type_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.invoice_type_enum AS ENUM (
    'purchase',
    'sale',
    'stock',
    'damaged'
);


ALTER TYPE public.invoice_type_enum OWNER TO root;

--
-- Name: products_type_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.products_type_enum AS ENUM (
    'single',
    'dependent',
    'combination',
    'multi'
);


ALTER TYPE public.products_type_enum OWNER TO root;

--
-- Name: transaction_type_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.transaction_type_enum AS ENUM (
    'purchase',
    'sale',
    'damage',
    'depo'
);


ALTER TYPE public.transaction_type_enum OWNER TO root;

--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public.users_role_enum AS ENUM (
    'admin',
    'user'
);


ALTER TYPE public.users_role_enum OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.categories OWNER TO root;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO root;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: colors; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.colors (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.colors OWNER TO root;

--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.colors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colors_id_seq OWNER TO root;

--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoice (
    id integer NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    total_amount integer NOT NULL,
    type public.invoice_type_enum NOT NULL,
    status public.invoice_status_enum DEFAULT 'success'::public.invoice_status_enum NOT NULL
);


ALTER TABLE public.invoice OWNER TO root;

--
-- Name: invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_id_seq OWNER TO root;

--
-- Name: invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.invoice_id_seq OWNED BY public.invoice.id;


--
-- Name: invoice_item; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoice_item (
    id integer NOT NULL,
    product_name character varying NOT NULL,
    quantity integer NOT NULL,
    price integer NOT NULL,
    status public.invoice_item_status_enum DEFAULT 'success'::public.invoice_item_status_enum NOT NULL,
    "invoiceId" integer
);


ALTER TABLE public.invoice_item OWNER TO root;

--
-- Name: invoice_item_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.invoice_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_item_id_seq OWNER TO root;

--
-- Name: invoice_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.invoice_item_id_seq OWNED BY public.invoice_item.id;


--
-- Name: product_settings; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.product_settings (
    id integer NOT NULL,
    reduce_price integer,
    min_price integer,
    is_active boolean DEFAULT false NOT NULL,
    "is_buyBox" boolean DEFAULT false NOT NULL,
    is_check_price boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    "productId" integer
);


ALTER TABLE public.product_settings OWNER TO root;

--
-- Name: product_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.product_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_settings_id_seq OWNER TO root;

--
-- Name: product_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.product_settings_id_seq OWNED BY public.product_settings.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying NOT NULL,
    image character varying,
    image_key character varying,
    price numeric,
    stock integer DEFAULT 0 NOT NULL,
    height numeric(5,1),
    width numeric(5,1),
    type public.products_type_enum DEFAULT 'single'::public.products_type_enum NOT NULL,
    dkp integer NOT NULL,
    dkpc integer NOT NULL,
    "categoryId" integer,
    "sellerId" integer NOT NULL,
    "colorId" integer,
    status boolean DEFAULT true NOT NULL,
    is_robot boolean DEFAULT false NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO root;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO root;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: related_product; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.related_product (
    id integer NOT NULL,
    quantity integer NOT NULL,
    "parentProductId" integer,
    "childProductId" integer
);


ALTER TABLE public.related_product OWNER TO root;

--
-- Name: related_product_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.related_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.related_product_id_seq OWNER TO root;

--
-- Name: related_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.related_product_id_seq OWNED BY public.related_product.id;


--
-- Name: sellers; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.sellers (
    id integer NOT NULL,
    name character varying NOT NULL,
    seller_id integer NOT NULL,
    email character varying,
    phone character varying,
    api_key character varying,
    access_token character varying,
    is_robot boolean DEFAULT false NOT NULL,
    robot_start_time numeric,
    "userId" integer NOT NULL
);


ALTER TABLE public.sellers OWNER TO root;

--
-- Name: sellers_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.sellers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sellers_id_seq OWNER TO root;

--
-- Name: sellers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.sellers_id_seq OWNED BY public.sellers.id;


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.transaction (
    id integer NOT NULL,
    price numeric,
    quantity integer NOT NULL,
    type public.transaction_type_enum NOT NULL,
    "userId" integer NOT NULL,
    "productId" integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.transaction OWNER TO root;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_id_seq OWNER TO root;

--
-- Name: transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.transaction_id_seq OWNED BY public.transaction.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(40) NOT NULL,
    email character varying NOT NULL,
    first_name character varying NOT NULL,
    last_name character varying NOT NULL,
    password character varying,
    role public.users_role_enum DEFAULT 'user'::public.users_role_enum NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: invoice id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice ALTER COLUMN id SET DEFAULT nextval('public.invoice_id_seq'::regclass);


--
-- Name: invoice_item id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_item ALTER COLUMN id SET DEFAULT nextval('public.invoice_item_id_seq'::regclass);


--
-- Name: product_settings id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.product_settings ALTER COLUMN id SET DEFAULT nextval('public.product_settings_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: related_product id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.related_product ALTER COLUMN id SET DEFAULT nextval('public.related_product_id_seq'::regclass);


--
-- Name: sellers id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sellers ALTER COLUMN id SET DEFAULT nextval('public.sellers_id_seq'::regclass);


--
-- Name: transaction id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.transaction ALTER COLUMN id SET DEFAULT nextval('public.transaction_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.categories (id, name) FROM stdin;
\.
COPY public.categories (id, name) FROM '$$PATH$$/3486.dat';

--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.colors (id, name) FROM stdin;
\.
COPY public.colors (id, name) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.invoice (id, date, total_amount, type, status) FROM stdin;
\.
COPY public.invoice (id, date, total_amount, type, status) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: invoice_item; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.invoice_item (id, product_name, quantity, price, status, "invoiceId") FROM stdin;
\.
COPY public.invoice_item (id, product_name, quantity, price, status, "invoiceId") FROM '$$PATH$$/3488.dat';

--
-- Data for Name: product_settings; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.product_settings (id, reduce_price, min_price, is_active, "is_buyBox", is_check_price, created_at, updated_at, "productId") FROM stdin;
\.
COPY public.product_settings (id, reduce_price, min_price, is_active, "is_buyBox", is_check_price, created_at, updated_at, "productId") FROM '$$PATH$$/3480.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.products (id, name, image, image_key, price, stock, height, width, type, dkp, dkpc, "categoryId", "sellerId", "colorId", status, is_robot, updated_at) FROM stdin;
\.
COPY public.products (id, name, image, image_key, price, stock, height, width, type, dkp, dkpc, "categoryId", "sellerId", "colorId", status, is_robot, updated_at) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: related_product; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.related_product (id, quantity, "parentProductId", "childProductId") FROM stdin;
\.
COPY public.related_product (id, quantity, "parentProductId", "childProductId") FROM '$$PATH$$/3482.dat';

--
-- Data for Name: sellers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.sellers (id, name, seller_id, email, phone, api_key, access_token, is_robot, robot_start_time, "userId") FROM stdin;
\.
COPY public.sellers (id, name, seller_id, email, phone, api_key, access_token, is_robot, robot_start_time, "userId") FROM '$$PATH$$/3476.dat';

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.transaction (id, price, quantity, type, "userId", "productId", created_at) FROM stdin;
\.
COPY public.transaction (id, price, quantity, type, "userId", "productId", created_at) FROM '$$PATH$$/3472.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.users (id, username, email, first_name, last_name, password, role, created_at) FROM stdin;
\.
COPY public.users (id, username, email, first_name, last_name, password, role, created_at) FROM '$$PATH$$/3474.dat';

--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.categories_id_seq', 10705, true);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.colors_id_seq', 8, true);


--
-- Name: invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.invoice_id_seq', 1, false);


--
-- Name: invoice_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.invoice_item_id_seq', 1, false);


--
-- Name: product_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.product_settings_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.products_id_seq', 798, true);


--
-- Name: related_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.related_product_id_seq', 1, false);


--
-- Name: sellers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.sellers_id_seq', 1, false);


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.transaction_id_seq', 6664, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: products PK_0806c755e0aca124e67c0cf6d7d; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "PK_0806c755e0aca124e67c0cf6d7d" PRIMARY KEY (id);


--
-- Name: invoice PK_15d25c200d9bcd8a33f698daf18; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT "PK_15d25c200d9bcd8a33f698daf18" PRIMARY KEY (id);


--
-- Name: categories PK_24dbc6126a28ff948da33e97d3b; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_24dbc6126a28ff948da33e97d3b" PRIMARY KEY (id);


--
-- Name: colors PK_3a62edc12d29307872ab1777ced; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "PK_3a62edc12d29307872ab1777ced" PRIMARY KEY (id);


--
-- Name: invoice_item PK_621317346abdf61295516f3cb76; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_item
    ADD CONSTRAINT "PK_621317346abdf61295516f3cb76" PRIMARY KEY (id);


--
-- Name: transaction PK_89eadb93a89810556e1cbcd6ab9; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT "PK_89eadb93a89810556e1cbcd6ab9" PRIMARY KEY (id);


--
-- Name: product_settings PK_8a366b7c7a94f8691b9e40b3bb5; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.product_settings
    ADD CONSTRAINT "PK_8a366b7c7a94f8691b9e40b3bb5" PRIMARY KEY (id);


--
-- Name: sellers PK_97337ccbf692c58e6c7682de8a2; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sellers
    ADD CONSTRAINT "PK_97337ccbf692c58e6c7682de8a2" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: related_product PK_ac12513597c02c2e5c04f873aae; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.related_product
    ADD CONSTRAINT "PK_ac12513597c02c2e5c04f873aae" PRIMARY KEY (id);


--
-- Name: product_settings REL_a6f67d1e4c2f96f863fe41473a; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.product_settings
    ADD CONSTRAINT "REL_a6f67d1e4c2f96f863fe41473a" UNIQUE ("productId");


--
-- Name: categories UQ_8b0be371d28245da6e4f4b61878; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "UQ_8b0be371d28245da6e4f4b61878" UNIQUE (name);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: colors UQ_cf12321fa0b7b9539e89c7dfeb7; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "UQ_cf12321fa0b7b9539e89c7dfeb7" UNIQUE (name);


--
-- Name: users UQ_fe0bb3f6520ee0469504521e710; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_fe0bb3f6520ee0469504521e710" UNIQUE (username);


--
-- Name: sellers FK_4c1c59db4ac1ed90a1a7c0ff3df; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sellers
    ADD CONSTRAINT "FK_4c1c59db4ac1ed90a1a7c0ff3df" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoice_item FK_553d5aac210d22fdca5c8d48ead; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_item
    ADD CONSTRAINT "FK_553d5aac210d22fdca5c8d48ead" FOREIGN KEY ("invoiceId") REFERENCES public.invoice(id);


--
-- Name: transaction FK_605baeb040ff0fae995404cea37; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT "FK_605baeb040ff0fae995404cea37" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: related_product FK_6d428324bf367f0aa09a5c13dd0; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.related_product
    ADD CONSTRAINT "FK_6d428324bf367f0aa09a5c13dd0" FOREIGN KEY ("parentProductId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: related_product FK_7b7c0ed9000730ae215febbce78; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.related_product
    ADD CONSTRAINT "FK_7b7c0ed9000730ae215febbce78" FOREIGN KEY ("childProductId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products FK_977ca0c3cae8850c2a5f49e3f13; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_977ca0c3cae8850c2a5f49e3f13" FOREIGN KEY ("colorId") REFERENCES public.colors(id) ON DELETE SET NULL;


--
-- Name: product_settings FK_a6f67d1e4c2f96f863fe41473a7; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.product_settings
    ADD CONSTRAINT "FK_a6f67d1e4c2f96f863fe41473a7" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products FK_e40a1dd2909378f0da1f34f7bd6; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_e40a1dd2909378f0da1f34f7bd6" FOREIGN KEY ("sellerId") REFERENCES public.sellers(id) ON DELETE SET NULL;


--
-- Name: transaction FK_fd965536176f304a7dd64937165; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT "FK_fd965536176f304a7dd64937165" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products FK_ff56834e735fa78a15d0cf21926; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_ff56834e735fa78a15d0cf21926" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

